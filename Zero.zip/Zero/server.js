const express = require('express');
const { MongoClient } = require('mongodb');

const app = express();
const PORTA = 80;
const client = new MongoClient('mongodb://localhost:27017');
let colecao;

app.set('view engine', 'ejs');     
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));   

app.get('/', (req, res) =>{
    res.render('home');
});

app.post('/porta', async (req, res) => {
    const bane = {
        titulo: req.body.titulo,
        descricao: req.body.descricao,
        local: req.body.local,
        data: req.body.data,
        hora: req.body.hora
    };
  await colecao.insertOne(bane);
  res.render('resposta');
})

app.get('/listar', async (req, res) => {
    const lembrete = await colecao.find().toArray();
    res.render('view', { lembrete });
});

client.connect().then(() => {
  colecao = client.db('meubanco').collection('pessoas'); // mensagens
  app.listen(PORTA, () => console.log('Servidor em http://localhost'));
}).catch(err => console.error('Erro ao conectar no BD:', err));


//cmd
//npm init, enter, enter, enter, enter, enter, enter, enter, enter
//npm install express, mongodb, ejs
//npm start